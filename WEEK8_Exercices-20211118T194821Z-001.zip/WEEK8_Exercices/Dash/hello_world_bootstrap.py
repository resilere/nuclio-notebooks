import dash
import dash_core_components as dcc
import dash_html_components as html
import dash_bootstrap_components as dbc
import plotly.express as px
import pandas as pd

extenal_stylesheets = [dbc.themes.BOOTSTRAP]
app = dash.Dash(__name__, external_stylesheets = extenal_stylesheets)

# Define layout
app.layout = dbc.Container(children=[
    # Row 1
    dbc.Row([
        dbc.Col([
            html.H1(children='Hello Dash'),
        ]),
    ]),
    # Row 2
    dbc.Row([
        dbc.Col([
            html.Div(children='''
                Dash: A web application framework for your data.
            '''),
        ]),
    ]),
])

if __name__ == '__main__':
    app.run_server(debug=True)
